<h2>Web project Starter</h2>
Dit is een repo om makkelijk een nieuw project te starten met Docker.

Installeer Docker wanneer je dit nog niet hebt gedaan; https://www.docker.com/products/docker-desktop/

Wanneer je de repo hebt gecloned doe je in de folder de volgende command uitvoeren; ```docker-compose up -d```

De docker container draait nu en je kunt nu in de app folder je project bouwen
