<?php include 'index/header.php'; ?>
<?php include 'quiz/addQuizMain.php'; ?>

<script type="text/javascript" src="js/addQuiz.js"></script>