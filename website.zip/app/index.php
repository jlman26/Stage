<?php include 'index/header.php'; ?>
<?php include 'index/main.php'; ?>
<?php include 'index/footer.php'; ?>
